#include "ui.h"



int main() {

	PlayBot();




	return 0;
}